#include <stdio.h>
#include <math.h>
double * solver(int,int,int);
double answer[2]; 
int delta;

int main(){
    int a,b,c;
    printf("enter a");
    scanf("%d",&a);
    printf("enter b");
    scanf("%d",&b);
    printf("enter c");
    scanf("%d",&c);
    delta=b*b-4*a*c;
    if (delta<0)
        printf("no real roots");
    else if(a==0 && b==0)
        printf("error");
    else if(delta!=0) {
		printf ("the roots are %lf & %lf", *(solver(a, b, c)), *(solver(a, b, c) + 1));
    }
    else if (delta==0)
    	printf ("the root is %lf", *(solver(a, b, c)));
    return 0;
}
double * solver(int a,int b , int c){
    double ans1=(double)(sqrt(delta)-b)/(2*a);
    double ans2=(double)(-sqrt(delta)-b)/(2*a);
    answer[0] = ans1;
    answer[1] = ans2;
    return answer;
}