#include <stdio.h>
#include <string.h>
int main(){
    int n;
    printf("enter n  ");
    scanf("%d", & n);
    char phr[n];
    char g=getchar();
    printf("enter a phrase  ");
    scanf("%s", phr); 
    int check=1;
    while(check=1 && n>=2) {
           check=0;
           for(int i=0 ; i<n-1; i++){ 
               if(phr[i]==phr[i+1]){
                check=1;
                for(int k=i;k<n-2 ;k++)
                   phr[k]=phr[k+2];
                n=n-2;
                for(int j=0;j<n;j++)
                   printf("%c",phr[j]);
                printf("\n");
               } 
           }
    }
    return 0 ;
}